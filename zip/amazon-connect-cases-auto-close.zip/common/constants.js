const constants = {
    'caseStatusOpen':'open',
    'caseStatusClosed':'closed'
}

module.exports = constants